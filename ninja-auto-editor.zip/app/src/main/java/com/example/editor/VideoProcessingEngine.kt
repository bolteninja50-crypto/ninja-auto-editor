package com.example.editor

import android.content.Context
import android.graphics.*
import android.media.*
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.*
import com.example.data.EditorSettings
import com.example.data.ExportQuality
import com.example.data.MemeAsset
import com.example.data.OutputMode
import com.example.data.WatermarkPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

@OptIn(UnstableApi::class)
class VideoProcessingEngine(private val context: Context) {

    private val mediaStoreExporter = MediaStoreExporter(context)

    interface ProgressListener {
        fun onProgress(percent: Int)
    }

    suspend fun processAndExport(
        inputUri: Uri,
        outputMode: OutputMode,
        quality: ExportQuality,
        settings: EditorSettings,
        memes: List<MemeAsset>,
        listener: ProgressListener
    ): List<File> = withContext(Dispatchers.IO) {
        val exportedFiles = mutableListOf<File>()
        val analyzer = VideoAnalyzer(context)
        val detector = HighlightDetector()

        listener.onProgress(5)
        val metadata = analyzer.extractMetadata(inputUri)
        val peaks = analyzer.analyzeAudioPeaks(inputUri, metadata.durationMs)
        listener.onProgress(20)

        when (outputMode) {
            OutputMode.SHORTS -> {
                val shortsSegments = detector.findHighlightShorts(
                    peaks = peaks,
                    videoDurationMs = metadata.durationMs,
                    minDurationSec = settings.minShortDurationSec,
                    maxDurationSec = settings.maxShortDurationSec,
                    targetClipCount = settings.numberOfShorts
                )

                val stepProgress = 70f / shortsSegments.size.coerceAtLeast(1)
                shortsSegments.forEachIndexed { index, segment ->
                    val shortName = "KingNinja55_Short_${String.format("%03d", index + 1)}.mp4"
                    val tempOutFile = File(context.cacheDir, "temp_$shortName")

                    val success = exportShortClip(
                        inputUri = inputUri,
                        segment = segment,
                        quality = quality,
                        settings = settings,
                        destFile = tempOutFile
                    )

                    if (success && tempOutFile.exists()) {
                        val savedFile = mediaStoreExporter.saveVideoToNinjaFolder(tempOutFile, shortName, "Shorts")
                        exportedFiles.add(savedFile)
                        tempOutFile.delete()
                    }
                    val currentProgress = 20 + ((index + 1) * stepProgress).toInt()
                    listener.onProgress(currentProgress.coerceAtMost(95))
                }
            }

            OutputMode.LONG -> {
                val longName = "KingNinja55_Long_Edit.mp4"
                val tempOutFile = File(context.cacheDir, "temp_$longName")

                val activeRanges = detector.findActiveLongVideoRanges(peaks, metadata.durationMs)
                val success = exportLongVideo(
                    inputUri = inputUri,
                    activeRanges = activeRanges,
                    quality = quality,
                    settings = settings,
                    memes = memes,
                    destFile = tempOutFile
                )

                if (success && tempOutFile.exists()) {
                    val savedFile = mediaStoreExporter.saveVideoToNinjaFolder(tempOutFile, longName, "LongVideos")
                    exportedFiles.add(savedFile)
                    tempOutFile.delete()
                }
                listener.onProgress(95)
            }

            OutputMode.BOTH -> {
                // Export Shorts first
                val shortsSegments = detector.findHighlightShorts(
                    peaks = peaks,
                    videoDurationMs = metadata.durationMs,
                    minDurationSec = settings.minShortDurationSec,
                    maxDurationSec = settings.maxShortDurationSec,
                    targetClipCount = settings.numberOfShorts
                )

                shortsSegments.forEachIndexed { index, segment ->
                    val shortName = "KingNinja55_Short_${String.format("%03d", index + 1)}.mp4"
                    val tempOutFile = File(context.cacheDir, "temp_$shortName")

                    val success = exportShortClip(
                        inputUri = inputUri,
                        segment = segment,
                        quality = quality,
                        settings = settings,
                        destFile = tempOutFile
                    )

                    if (success && tempOutFile.exists()) {
                        val savedFile = mediaStoreExporter.saveVideoToNinjaFolder(tempOutFile, shortName, "Shorts")
                        exportedFiles.add(savedFile)
                        tempOutFile.delete()
                    }
                }
                listener.onProgress(60)

                // Export Long Video second
                val longName = "KingNinja55_Long_Edit.mp4"
                val tempOutFile = File(context.cacheDir, "temp_$longName")
                val activeRanges = detector.findActiveLongVideoRanges(peaks, metadata.durationMs)
                val success = exportLongVideo(
                    inputUri = inputUri,
                    activeRanges = activeRanges,
                    quality = quality,
                    settings = settings,
                    memes = memes,
                    destFile = tempOutFile
                )

                if (success && tempOutFile.exists()) {
                    val savedFile = mediaStoreExporter.saveVideoToNinjaFolder(tempOutFile, longName, "LongVideos")
                    exportedFiles.add(savedFile)
                    tempOutFile.delete()
                }
                listener.onProgress(95)
            }
        }

        listener.onProgress(100)
        return@withContext exportedFiles
    }

    private fun exportShortClip(
        inputUri: Uri,
        segment: HighlightSegment,
        quality: ExportQuality,
        settings: EditorSettings,
        destFile: File
    ): Boolean {
        return try {
            val targetWidth = if (quality == ExportQuality.P1080) 1080 else 720
            val targetHeight = if (quality == ExportQuality.P1080) 1920 else 1280

            val editedMediaItem = MediaItem.Builder()
                .setUri(inputUri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(segment.startTimeMs)
                        .setEndPositionMs(segment.endTimeMs)
                        .build()
                )
                .build()

            // Transcode with Media3 Transformer or Fast MediaCodec composition
            runTransformerExportSync(editedMediaItem, destFile)
            
            // If primary export failed or output is missing, execute resilient direct extractor clip fallback
            if (!destFile.exists() || destFile.length() == 0L) {
                runDirectMediaMuxerClip(inputUri, segment.startTimeMs, segment.endTimeMs, destFile)
            }
            true
        } catch (e: Exception) {
            Log.e("VideoProcessingEngine", "Error exporting short clip", e)
            runDirectMediaMuxerClip(inputUri, segment.startTimeMs, segment.endTimeMs, destFile)
        }
    }

    private fun exportLongVideo(
        inputUri: Uri,
        activeRanges: List<Pair<Long, Long>>,
        quality: ExportQuality,
        settings: EditorSettings,
        memes: List<MemeAsset>,
        destFile: File
    ): Boolean {
        return try {
            val firstRange = activeRanges.firstOrNull() ?: (0L to 60000L)
            val editedMediaItem = MediaItem.Builder()
                .setUri(inputUri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(firstRange.first)
                        .setEndPositionMs(firstRange.second)
                        .build()
                )
                .build()

            runTransformerExportSync(editedMediaItem, destFile)

            if (!destFile.exists() || destFile.length() == 0L) {
                runDirectMediaMuxerClip(inputUri, firstRange.first, firstRange.second, destFile)
            }
            true
        } catch (e: Exception) {
            Log.e("VideoProcessingEngine", "Error exporting long video", e)
            val duration = activeRanges.firstOrNull()?.second ?: 60000L
            runDirectMediaMuxerClip(inputUri, 0L, duration, destFile)
        }
    }

    private fun runTransformerExportSync(mediaItem: MediaItem, destFile: File): Boolean {
        var completed = false
        var failed = false
        val lock = java.lang.Object()

        val mainHandler = Handler(Looper.getMainLooper())
        mainHandler.post {
            try {
                val transformer = Transformer.Builder(context)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            synchronized(lock) {
                                completed = true
                                lock.notifyAll()
                            }
                        }

                        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                            Log.e("VideoProcessingEngine", "Transformer error", exportException)
                            synchronized(lock) {
                                failed = true
                                lock.notifyAll()
                            }
                        }
                    })
                    .build()

                transformer.start(mediaItem, destFile.absolutePath)
            } catch (e: Exception) {
                Log.e("VideoProcessingEngine", "Failed to start transformer", e)
                synchronized(lock) {
                    failed = true
                    lock.notifyAll()
                }
            }
        }

        synchronized(lock) {
            try {
                lock.wait(15000L) // wait up to 15s per clip on device
            } catch (_: InterruptedException) {}
        }

        return completed && !failed && destFile.exists() && destFile.length() > 0L
    }

    private fun runDirectMediaMuxerClip(
        inputUri: Uri,
        startMs: Long,
        endMs: Long,
        destFile: File
    ): Boolean {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null

        return try {
            extractor.setDataSource(context, inputUri, null)
            muxer = MediaMuxer(destFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val trackMap = HashMap<Int, Int>()
            var maxBufferSize = 1024 * 1024

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    val newIndex = muxer.addTrack(format)
                    trackMap[i] = newIndex
                    if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        val size = format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                        if (size > maxBufferSize) maxBufferSize = size
                    }
                }
            }

            muxer.start()

            val startUs = startMs * 1000L
            val endUs = endMs * 1000L

            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val buffer = ByteBuffer.allocate(maxBufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break

                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs > endUs) break

                if (sampleTimeUs >= startUs) {
                    val trackIndex = extractor.sampleTrackIndex
                    val muxerTrackIndex = trackMap[trackIndex]

                    if (muxerTrackIndex != null) {
                        bufferInfo.offset = 0
                        bufferInfo.size = sampleSize
                        bufferInfo.presentationTimeUs = sampleTimeUs - startUs
                        bufferInfo.flags = extractor.sampleFlags

                        muxer.writeSampleData(muxerTrackIndex, buffer, bufferInfo)
                    }
                }

                extractor.advance()
            }

            true
        } catch (e: Exception) {
            Log.e("VideoProcessingEngine", "Direct MediaMuxer clip failed", e)
            false
        } finally {
            try { extractor.release() } catch (_: Exception) {}
            try {
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {}
        }
    }
}
