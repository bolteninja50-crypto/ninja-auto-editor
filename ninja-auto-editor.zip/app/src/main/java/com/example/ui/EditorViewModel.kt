package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.*
import com.example.editor.VideoAnalyzer
import com.example.editor.VideoMetadata
import com.example.worker.VideoExportWorker
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val workManager = WorkManager.getInstance(application)
    private val analyzer = VideoAnalyzer(application)

    val settings: StateFlow<EditorSettings> = db.settingsDao().getSettingsFlow()
        .map { it ?: EditorSettings() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), EditorSettings())

    val memes: StateFlow<List<MemeAsset>> = db.memeDao().getAllMemesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val projects: StateFlow<List<ExportProject>> = db.exportDao().getAllProjectsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProject: StateFlow<ExportProject?> = db.exportDao().getActiveProjectFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _selectedVideoUri = MutableStateFlow<Uri?>(null)
    val selectedVideoUri: StateFlow<Uri?> = _selectedVideoUri.asStateFlow()

    private val _selectedVideoMetadata = MutableStateFlow<VideoMetadata?>(null)
    val selectedVideoMetadata: StateFlow<VideoMetadata?> = _selectedVideoMetadata.asStateFlow()

    private val _selectedOutputMode = MutableStateFlow(OutputMode.SHORTS)
    val selectedOutputMode: StateFlow<OutputMode> = _selectedOutputMode.asStateFlow()

    private val _selectedQuality = MutableStateFlow(ExportQuality.P1080)
    val selectedQuality: StateFlow<ExportQuality> = _selectedQuality.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    fun selectVideo(uri: Uri) {
        _selectedVideoUri.value = uri
        _isAnalyzing.value = true
        viewModelScope.launch {
            val metadata = analyzer.extractMetadata(uri)
            _selectedVideoMetadata.value = metadata
            _isAnalyzing.value = false
        }
    }

    fun setOutputMode(mode: OutputMode) {
        _selectedOutputMode.value = mode
    }

    fun setQuality(quality: ExportQuality) {
        _selectedQuality.value = quality
    }

    fun updateMemeFrequency(frequency: MemeFrequency) {
        viewModelScope.launch {
            val current = settings.value
            db.settingsDao().insertOrUpdateSettings(current.copy(memeFrequency = frequency))
        }
    }

    fun toggleMasterMemes(enabled: Boolean) {
        viewModelScope.launch {
            val current = settings.value
            db.settingsDao().insertOrUpdateSettings(current.copy(masterMemesEnabled = enabled))
        }
    }

    fun updateSettings(newSettings: EditorSettings) {
        viewModelScope.launch {
            db.settingsDao().insertOrUpdateSettings(newSettings)
        }
    }

    fun startAutoEdit() {
        val uri = selectedVideoUri.value ?: return
        val metadata = selectedVideoMetadata.value ?: return

        viewModelScope.launch {
            val project = ExportProject(
                title = metadata.fileName.replace(".mp4", "", ignoreCase = true),
                sourceVideoUri = uri.toString(),
                outputType = selectedOutputMode.value,
                quality = selectedQuality.value,
                durationMs = metadata.durationMs,
                status = ExportStatus.QUEUED
            )

            val projectId = db.exportDao().insertProject(project)

            val inputData = Data.Builder()
                .putLong(VideoExportWorker.KEY_PROJECT_ID, projectId)
                .build()

            val workRequest = OneTimeWorkRequestBuilder<VideoExportWorker>()
                .setInputData(inputData)
                .build()

            workManager.enqueue(workRequest)
        }
    }

    fun addMemeAsset(title: String, filePath: String, mediaType: MemeMediaType, category: MemeCategory) {
        viewModelScope.launch {
            val meme = MemeAsset(
                title = title,
                filePath = filePath,
                mediaType = mediaType,
                category = category
            )
            db.memeDao().insertMeme(meme)
        }
    }

    fun deleteMemeAsset(meme: MemeAsset) {
        viewModelScope.launch {
            db.memeDao().deleteMeme(meme)
        }
    }

    fun deleteProject(project: ExportProject) {
        viewModelScope.launch {
            db.exportDao().deleteProject(project)
        }
    }
}
