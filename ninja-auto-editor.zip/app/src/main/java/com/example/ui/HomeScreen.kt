package com.example.ui

import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.data.*
import com.example.ui.theme.*
import java.io.File

@OptIn(UnstableApi::class)
@Composable
fun HomeScreen(
    viewModel: EditorViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToMemes: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val selectedUri by viewModel.selectedVideoUri.collectAsStateWithLifecycle()
    val selectedMetadata by viewModel.selectedVideoMetadata.collectAsStateWithLifecycle()
    val outputMode by viewModel.selectedOutputMode.collectAsStateWithLifecycle()
    val quality by viewModel.selectedQuality.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeProject.collectAsStateWithLifecycle()

    var showLargeVideoWarning by remember { mutableStateOf(false) }

    LaunchedEffect(selectedMetadata) {
        selectedMetadata?.let { meta ->
            if (meta.width > 1920 || meta.height > 1920 || meta.durationMs > 1800000L) {
                showLargeVideoWarning = true
            }
        }
    }

    if (showLargeVideoWarning) {
        AlertDialog(
            onDismissRequest = { showLargeVideoWarning = false },
            title = {
                Text(
                    text = "LARGE / 4K VIDEO DETECTED",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = NinjaRedGlow
                )
            },
            text = {
                Text(
                    text = "High-resolution video processing requires hardware encoding. Mobile rendering may take additional time or produce slight warmth. Local hardware limits to 1 active export at a time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = NinjaTextWhite
                )
            },
            confirmButton = {
                Button(
                    onClick = { showLargeVideoWarning = false },
                    colors = ButtonDefaults.buttonColors(containerColor = NinjaRedPrimary)
                ) {
                    Text("CONTINUE", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = NinjaDarkSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.selectVideo(it) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NinjaDarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        // Esports Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("header_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NinjaDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "NINJA AUTO EDITOR",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                letterSpacing = (-0.5).sp
                            ),
                            color = NinjaRedPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "CHANNEL: ${settings.channelName.uppercase()}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            ),
                            color = NinjaTextSubtle
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(onClick = onNavigateToAbout, modifier = Modifier.testTag("about_btn")) {
                            Icon(Icons.Default.Info, contentDescription = "About", tint = NinjaTextWhite)
                        }
                        IconButton(onClick = onNavigateToMemes, modifier = Modifier.testTag("memes_btn")) {
                            Icon(Icons.Default.SentimentVerySatisfied, contentDescription = "Memes", tint = NinjaTextWhite)
                        }
                        IconButton(onClick = onNavigateToHistory, modifier = Modifier.testTag("history_btn")) {
                            Icon(Icons.Default.History, contentDescription = "History", tint = NinjaTextWhite)
                        }
                        IconButton(onClick = onNavigateToSettings, modifier = Modifier.testTag("settings_btn")) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = NinjaRedGlow)
                        }

                        Spacer(modifier = Modifier.width(2.dp))

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(NinjaRedPrimary)
                                .border(2.dp, NinjaRedGlow.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (settings.channelName.length >= 2) settings.channelName.take(2).uppercase() else "KN",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                ),
                                color = NinjaTextWhite
                            )
                        }
                    }
                }
            }
        }

        // Active Project Export Progress Card
        activeProject?.let { project ->
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("active_project_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NinjaDarkSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NinjaRedPrimary)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "EDITING: ${project.title}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = NinjaTextWhite
                            )
                            Text(
                                text = "${project.progressPercent}%",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                color = NinjaRedGlow
                            )
                        }

                        LinearProgressIndicator(
                            progress = { project.progressPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = NinjaRedPrimary,
                            trackColor = NinjaDarkBackground
                        )

                        Text(
                            text = when (project.status) {
                                ExportStatus.QUEUED -> "Queued for local processing..."
                                ExportStatus.PROCESSING -> "Detecting highlights, cropping & exporting MP4..."
                                ExportStatus.COMPLETED -> "Export Completed! Saved to Movies/NinjaAutoEditor"
                                ExportStatus.FAILED -> "Export Failed: ${project.errorMessage}"
                                ExportStatus.CANCELLED -> "Export Cancelled"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (project.status == ExportStatus.FAILED) Color.Red else NinjaTextMuted
                        )

                        if (project.status == ExportStatus.COMPLETED && project.outputFilePath != null) {
                            val outputFile = File(project.outputFilePath)
                            if (outputFile.exists()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                KeyVideoPreviewPlayer(filePath = project.outputFilePath)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val uri = FileProvider.getUriForFile(
                                                context,
                                                "${context.packageName}.fileprovider",
                                                outputFile
                                            )
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "video/mp4"
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Ninja Video"))
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = NinjaRedPrimary),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("SHARE", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Gameplay Video Preview & Selector
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { videoPickerLauncher.launch("video/*") }
                    .testTag("select_video_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NinjaDarkSurface),
                border = androidx.compose.foundation.BorderStroke(
                    width = 1.dp,
                    color = if (selectedUri != null) NinjaRedPrimary.copy(alpha = 0.8f) else NinjaCardOutline
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .background(NinjaDarkSurface)
                ) {
                    if (selectedUri == null) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.08f))
                                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VideoCall,
                                    contentDescription = "Select Video",
                                    tint = NinjaRedPrimary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "SELECT GAMEPLAY VIDEO",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.5.sp
                                ),
                                color = NinjaTextWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap to import long gameplay recording for auto-editing",
                                style = MaterialTheme.typography.bodySmall,
                                color = NinjaTextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        // Styled Active Video Preview Display
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Top Row: Duration Badge & Change Button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val durSec = (selectedMetadata?.durationMs ?: 0L) / 1000
                                    val durMin = durSec / 60
                                    val remSec = durSec % 60
                                    Surface(
                                        color = Color.Black.copy(alpha = 0.7f),
                                        shape = RoundedCornerShape(6.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
                                    ) {
                                        Text(
                                            text = String.format("%02d:%02d", durMin, remSec),
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = NinjaTextWhite,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                TextButton(
                                    onClick = { videoPickerLauncher.launch("video/*") },
                                    colors = ButtonDefaults.textButtonColors(contentColor = NinjaRedGlow)
                                ) {
                                    Text("CHANGE", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                            }

                            // Center Play Icon Badge
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .align(Alignment.CenterHorizontally)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.12f))
                                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = NinjaTextWhite,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            // Bottom Status Bar Overlay
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(NinjaSuccessGreen)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${selectedMetadata?.fileName ?: "Gameplay_042.mp4"} Analyzed",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.5.sp
                                        ),
                                        color = NinjaTextWhite
                                    )
                                }

                                if (isAnalyzing) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(14.dp),
                                            color = NinjaRedPrimary,
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Analyzing...",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = NinjaTextMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Configuration Section: Output Format
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("output_mode_card"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "SELECT OUTPUT FORMAT",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        ),
                        color = NinjaRedPrimary
                    )
                    Text(
                        text = "STEP 1 OF 3",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                        color = NinjaTextSubtle
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutputModeChip(
                        title = "Auto Shorts",
                        subtitle = "9:16 Vertical • 1080p\n3-10 Clips Heuristic",
                        isSelected = outputMode == OutputMode.SHORTS,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setOutputMode(OutputMode.SHORTS) }
                    )
                    OutputModeChip(
                        title = "Full Edit",
                        subtitle = "16:9 Cinema • 1080p\nTrimmed Silent Gaps",
                        isSelected = outputMode == OutputMode.LONG,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setOutputMode(OutputMode.LONG) }
                    )
                    OutputModeChip(
                        title = "Both Formats",
                        subtitle = "Shorts + Full Edit\nDual Render",
                        isSelected = outputMode == OutputMode.BOTH,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setOutputMode(OutputMode.BOTH) }
                    )
                }
            }
        }

        // Resolution Configuration
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quality_card"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "SELECT RESOLUTION",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        ),
                        color = NinjaRedPrimary
                    )
                    Text(
                        text = "STEP 2 OF 3",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                        color = NinjaTextSubtle
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QualityChip(
                        title = "720p HD",
                        subtitle = "Fast Hardware Encode",
                        isSelected = quality == ExportQuality.P720,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setQuality(ExportQuality.P720) }
                    )
                    QualityChip(
                        title = "1080p Full HD",
                        subtitle = "Maximum Esports Clarity",
                        isSelected = quality == ExportQuality.P1080,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setQuality(ExportQuality.P1080) }
                    )
                }
            }
        }

        // Meme Frequency & Intensity
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("meme_freq_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NinjaDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MEME FREQUENCY",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = NinjaTextMuted
                        )

                        val freqText = when (settings.memeFrequency) {
                            com.example.data.MemeFrequency.LOW -> "20%"
                            com.example.data.MemeFrequency.MEDIUM -> "50%"
                            com.example.data.MemeFrequency.HIGH -> "80%"
                        }
                        Text(
                            text = if (settings.masterMemesEnabled) "${settings.memeFrequency.name} ($freqText)" else "DISABLED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            color = if (settings.masterMemesEnabled) NinjaRedGlow else NinjaTextSubtle
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Enable Memes & Sound FX",
                            style = MaterialTheme.typography.bodySmall,
                            color = NinjaTextWhite
                        )
                        Switch(
                            checked = settings.masterMemesEnabled,
                            onCheckedChange = { viewModel.toggleMasterMemes(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = NinjaTextWhite,
                                checkedTrackColor = NinjaRedPrimary,
                                uncheckedThumbColor = NinjaTextMuted,
                                uncheckedTrackColor = NinjaDarkSurfaceVariant
                            )
                        )
                    }

                    if (settings.masterMemesEnabled) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MemeFrequency.entries.forEach { freq ->
                                val isSelected = settings.memeFrequency == freq
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { viewModel.updateMemeFrequency(freq) },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) NinjaRedPrimary else NinjaDarkSurfaceVariant,
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, NinjaRedGlow) else null
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = freq.name,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = NinjaTextWhite
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("CONSERVATIVE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = NinjaTextSubtle)
                            Text("CHAOTIC", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = NinjaTextSubtle)
                        }
                    }
                }
            }
        }

        // Edit Style Presets Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("presets_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NinjaDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "PRESET CONFIGURATIONS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = NinjaTextMuted
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Preset 1: Clean Edit
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    viewModel.setOutputMode(OutputMode.LONG)
                                    viewModel.toggleMasterMemes(false)
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = NinjaDarkSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🎬 Clean Edit", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = NinjaTextWhite)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("No Memes • Trimmed", style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp), color = NinjaTextMuted)
                            }
                        }

                        // Preset 2: Funny Gaming
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    viewModel.setOutputMode(OutputMode.BOTH)
                                    viewModel.toggleMasterMemes(true)
                                    viewModel.updateMemeFrequency(MemeFrequency.MEDIUM)
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = NinjaDarkSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("😂 Funny Gaming", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = NinjaTextWhite)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Medium Memes • Both", style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp), color = NinjaTextMuted)
                            }
                        }

                        // Preset 3: Fast Viral Shorts
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    viewModel.setOutputMode(OutputMode.SHORTS)
                                    viewModel.toggleMasterMemes(true)
                                    viewModel.updateMemeFrequency(MemeFrequency.HIGH)
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = NinjaDarkSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🔥 Viral Shorts", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = NinjaTextWhite)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("High Memes • 9:16", style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp), color = NinjaTextMuted)
                            }
                        }
                    }
                }
            }
        }

        // Export Output Estimations Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("estimates_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NinjaDarkSurfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "ESTIMATED OUTPUT METRICS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = NinjaRedGlow
                    )

                    val estShortsCount = if (outputMode == OutputMode.LONG) 0 else settings.numberOfShorts
                    val estLongMins = if (outputMode == OutputMode.SHORTS) 0 else (((selectedMetadata?.durationMs ?: 60000L) * 0.75) / 1000 / 60).toInt().coerceAtLeast(1)
                    val estStorageMb = (estShortsCount * 22) + (if (outputMode != OutputMode.SHORTS) 75 else 0)
                    val estExportSec = (estShortsCount * 6) + (if (outputMode != OutputMode.SHORTS) 18 else 0)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Shorts Output", style = MaterialTheme.typography.labelSmall, color = NinjaTextSubtle)
                            Text("$estShortsCount Clips (9:16)", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = NinjaTextWhite)
                        }
                        Column {
                            Text("Full Long Edit", style = MaterialTheme.typography.labelSmall, color = NinjaTextSubtle)
                            Text("$estLongMins Mins Trimmed", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = NinjaTextWhite)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Est. Storage Required", style = MaterialTheme.typography.labelSmall, color = NinjaTextSubtle)
                            Text("~$estStorageMb MB", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = NinjaTextWhite)
                        }
                        Column {
                            Text("Est. Hardware Render", style = MaterialTheme.typography.labelSmall, color = NinjaTextSubtle)
                            Text("~$estExportSec Secs", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = NinjaRedPrimary)
                        }
                    }
                }
            }
        }

        // Primary Action: Glowing Red "Auto Edit Now" Button
        item {
            val isEnabled = selectedUri != null && (activeProject?.status != ExportStatus.PROCESSING)

            Button(
                onClick = { viewModel.startAutoEdit() },
                enabled = isEnabled,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .testTag("auto_edit_btn"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NinjaRedPrimary,
                    disabledContainerColor = NinjaDarkSurfaceVariant
                )
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (activeProject?.status == ExportStatus.PROCESSING) "AUTO EDITING..." else "AUTO EDIT NOW",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            letterSpacing = 2.sp
                        ),
                        color = if (isEnabled) NinjaTextWhite else NinjaTextSubtle
                    )
                    Text(
                        text = "LOCAL HARDWARE ENCODING",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 8.sp,
                            letterSpacing = 1.5.sp
                        ),
                        color = if (isEnabled) NinjaTextWhite.copy(alpha = 0.7f) else NinjaTextSubtle.copy(alpha = 0.5f)
                    )
                }
            }
        }

    }
}

@Composable
fun OutputModeChip(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = NinjaDarkSurfaceVariant
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) NinjaRedPrimary else Color.White.copy(alpha = 0.1f)
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(NinjaRedPrimary)
                        .align(Alignment.TopEnd)
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.Start
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) NinjaRedPrimary.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (title.contains("Shorts")) Icons.Default.Smartphone else Icons.Default.Tv,
                        contentDescription = null,
                        tint = if (isSelected) NinjaRedGlow else NinjaTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (isSelected) NinjaTextWhite else NinjaTextWhite.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, lineHeight = 12.sp),
                    color = if (isSelected) NinjaTextMuted else NinjaTextSubtle
                )
            }
        }
    }
}

@Composable
fun QualityChip(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = NinjaDarkSurfaceVariant
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) NinjaRedPrimary else Color.White.copy(alpha = 0.1f)
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(NinjaRedPrimary)
                        .align(Alignment.TopEnd)
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = if (isSelected) NinjaTextWhite else NinjaTextWhite.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                    color = if (isSelected) NinjaTextMuted else NinjaTextSubtle
                )
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun KeyVideoPreviewPlayer(filePath: String) {
    val context = LocalContext.current
    val exoPlayer = remember(filePath) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(filePath))))
            prepare()
        }
    }

    DisposableEffect(filePath) {
        onDispose {
            exoPlayer.release()
        }
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                player = exoPlayer
                useController = true
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    600
                )
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, NinjaCardOutline, RoundedCornerShape(8.dp))
    )
}
