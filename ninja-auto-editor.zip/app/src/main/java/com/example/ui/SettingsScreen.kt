package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.EditorSettings
import com.example.data.WatermarkPosition
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToAbout: () -> Unit = {}
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var channelNameState by remember(settings.channelName) { mutableStateOf(settings.channelName) }
    var minDurationState by remember(settings.minShortDurationSec) { mutableFloatStateOf(settings.minShortDurationSec.toFloat()) }
    var maxDurationState by remember(settings.maxShortDurationSec) { mutableFloatStateOf(settings.maxShortDurationSec.toFloat()) }
    var numberOfShortsState by remember(settings.numberOfShorts) { mutableFloatStateOf(settings.numberOfShorts.toFloat()) }
    var gameVolState by remember(settings.gameAudioVolume) { mutableFloatStateOf(settings.gameAudioVolume) }
    var memeVolState by remember(settings.memeAudioVolume) { mutableFloatStateOf(settings.memeAudioVolume) }

    val logoPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { viewModel.updateSettings(settings.copy(channelLogoPath = it.toString())) }
    }

    val outroPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { viewModel.updateSettings(settings.copy(outroVideoPath = it.toString())) }
    }

    val watermarkPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { viewModel.updateSettings(settings.copy(watermarkImagePath = it.toString())) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("EDITOR SETTINGS", color = NinjaTextWhite, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_btn")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NinjaTextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NinjaDarkBackground)
            )
        },
        containerColor = NinjaDarkBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Channel Branding Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("branding_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NinjaDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "CHANNEL BRANDING",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Black,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                letterSpacing = 0.5.sp
                            ),
                            color = NinjaRedPrimary
                        )

                        OutlinedTextField(
                            value = channelNameState,
                            onValueChange = {
                                channelNameState = it
                                viewModel.updateSettings(settings.copy(channelName = it))
                            },
                            label = { Text("Channel Name") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NinjaRedPrimary,
                                unfocusedBorderColor = NinjaCardOutline,
                                focusedTextColor = NinjaTextWhite,
                                unfocusedTextColor = NinjaTextWhite
                            )
                        )

                        // Channel Logo File Picker
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Channel Logo", color = NinjaTextWhite, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (settings.channelLogoPath != null) "Logo selected" else "No logo selected",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NinjaTextMuted
                                )
                            }
                            Button(
                                onClick = { logoPickerLauncher.launch("image/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = NinjaDarkSurfaceVariant)
                            ) {
                                Text(if (settings.channelLogoPath == null) "IMPORT PNG" else "CHANGE", color = NinjaRedGlow)
                            }
                        }

                        // 2-Second Outro MP4 Picker
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("2-Sec Outro Video", color = NinjaTextWhite, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (settings.outroVideoPath != null) "Outro MP4 selected" else "No outro selected",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NinjaTextMuted
                                )
                            }
                            Button(
                                onClick = { outroPickerLauncher.launch("video/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = NinjaDarkSurfaceVariant)
                            ) {
                                Text(if (settings.outroVideoPath == null) "IMPORT MP4" else "CHANGE", color = NinjaRedGlow)
                            }
                        }

                        // Watermark PNG Picker
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Watermark Image", color = NinjaTextWhite, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (settings.watermarkImagePath != null) "Watermark selected" else "No watermark selected",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NinjaTextMuted
                                )
                            }
                            Button(
                                onClick = { watermarkPickerLauncher.launch("image/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = NinjaDarkSurfaceVariant)
                            ) {
                                Text(if (settings.watermarkImagePath == null) "IMPORT PNG" else "CHANGE", color = NinjaRedGlow)
                            }
                        }
                    }
                }
            }

            // Short Clip Settings
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("short_settings_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NinjaDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "AUTO SHORTS PARAMETERS",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Black,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                letterSpacing = 0.5.sp
                            ),
                            color = NinjaRedPrimary
                        )

                        Text(
                            text = "Target Clip Count: ${numberOfShortsState.toInt()}",
                            color = NinjaTextWhite,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Slider(
                            value = numberOfShortsState,
                            onValueChange = {
                                numberOfShortsState = it
                                viewModel.updateSettings(settings.copy(numberOfShorts = it.toInt()))
                            },
                            valueRange = 3f..10f,
                            steps = 6,
                            colors = SliderDefaults.colors(
                                thumbColor = NinjaRedPrimary,
                                activeTrackColor = NinjaRedPrimary
                            )
                        )

                        Text(
                            text = "Duration Range: ${minDurationState.toInt()}s - ${maxDurationState.toInt()}s",
                            color = NinjaTextWhite,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Min Duration (${minDurationState.toInt()}s)", style = MaterialTheme.typography.labelSmall, color = NinjaTextMuted)
                                Slider(
                                    value = minDurationState,
                                    onValueChange = {
                                        minDurationState = it
                                        viewModel.updateSettings(settings.copy(minShortDurationSec = it.toInt()))
                                    },
                                    valueRange = 10f..25f,
                                    colors = SliderDefaults.colors(thumbColor = NinjaRedPrimary, activeTrackColor = NinjaRedPrimary)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Max Duration (${maxDurationState.toInt()}s)", style = MaterialTheme.typography.labelSmall, color = NinjaTextMuted)
                                Slider(
                                    value = maxDurationState,
                                    onValueChange = {
                                        maxDurationState = it
                                        viewModel.updateSettings(settings.copy(maxShortDurationSec = it.toInt()))
                                    },
                                    valueRange = 25f..50f,
                                    colors = SliderDefaults.colors(thumbColor = NinjaRedPrimary, activeTrackColor = NinjaRedPrimary)
                                )
                            }
                        }
                    }
                }
            }

            // Audio Mixers
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("audio_mixers_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NinjaDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "AUDIO VOLUME MIXERS",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Black,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                letterSpacing = 0.5.sp
                            ),
                            color = NinjaRedPrimary
                        )

                        Text("Gameplay Game Audio: ${(gameVolState * 100).toInt()}%", color = NinjaTextWhite)
                        Slider(
                            value = gameVolState,
                            onValueChange = {
                                gameVolState = it
                                viewModel.updateSettings(settings.copy(gameAudioVolume = it))
                            },
                            valueRange = 0f..1.5f,
                            colors = SliderDefaults.colors(thumbColor = NinjaRedPrimary, activeTrackColor = NinjaRedPrimary)
                        )

                        Text("Meme Sound FX: ${(memeVolState * 100).toInt()}%", color = NinjaTextWhite)
                        Slider(
                            value = memeVolState,
                            onValueChange = {
                                memeVolState = it
                                viewModel.updateSettings(settings.copy(memeAudioVolume = it))
                            },
                            valueRange = 0f..1.5f,
                            colors = SliderDefaults.colors(thumbColor = NinjaRedPrimary, activeTrackColor = NinjaRedPrimary)
                        )
                    }
                }
            }

            // About This Editor Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("about_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NinjaDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NinjaRedPrimary),
                    onClick = onNavigateToAbout
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "About",
                                tint = NinjaRedGlow,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "ABOUT THIS EDITOR",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = NinjaTextWhite
                                )
                                Text(
                                    text = "Offline heuristic engine & signal processing details",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NinjaTextMuted
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Open",
                            tint = NinjaTextMuted
                        )
                    }
                }
            }

            // Legal & Rights Disclaimer Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("disclaimer_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NinjaDarkSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NinjaCardOutline)
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gavel,
                            contentDescription = "Disclaimer",
                            tint = NinjaRedGlow,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "LEGAL DISCLAIMER & RIGHTS",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = NinjaTextWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Users must only process gameplay videos, memes, audio tracks, and assets that they have legal rights or permissions to use. All video processing occurs 100% locally on device.",
                                style = MaterialTheme.typography.labelSmall,
                                color = NinjaTextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}
